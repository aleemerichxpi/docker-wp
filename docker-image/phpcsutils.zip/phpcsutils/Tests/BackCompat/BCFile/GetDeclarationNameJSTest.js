/* testInvalidTokenPassed */
print something;

var object =
{
    /* testClosure */
    propertyName: function ()  {}
}

/* testFunction */
function functionName() {}

/* testClass */
class ClassName
{
    /* testMethod */
    methodName() {
       return false;
    }
}

/* testFunctionUnicode */
function π() {}
