The Arrays::isShortArray() method is tested together with the Lists::isShortList() method.
The tests for this can be found in the Lists folder.