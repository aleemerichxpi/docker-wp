<?php
function function_with_this_outside_class() {
    return $this->whatever();
}
