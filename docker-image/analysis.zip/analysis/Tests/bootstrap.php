<?php
require_once(__DIR__ . '/../vendor/squizlabs/php_codesniffer/tests/bootstrap.php');
require_once(__DIR__ . '/BaseTestCase.php');
